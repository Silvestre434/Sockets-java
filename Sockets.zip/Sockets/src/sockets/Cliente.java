/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package sockets;

import java.io.*;
import java.net.*;

public class Cliente {
    public static void main(String[] args) {
        String host = "localhost";
        int puerto = 5050;

        try (Socket socket = new Socket(host, puerto);
             BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
             BufferedReader entrada = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             PrintWriter salida = new PrintWriter(socket.getOutputStream(), true)) {

            System.out.println("Conectado al servidor en " + host + ":" + puerto);
            String mensaje;

            while (true) {
                System.out.print("Escribe mensaje: ");
                mensaje = teclado.readLine();
                salida.println(mensaje);

                String respuesta = entrada.readLine();
                if (respuesta == null) {
                    System.out.println("Servidor cerró la conexion.");
                    break;
                }
                System.out.println("Servidor: " + respuesta);

                if (mensaje.equalsIgnoreCase("salir")) {
                    break;
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

