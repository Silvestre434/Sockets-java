/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sockets;

import java.io.*;
import java.net.*;
import java.util.Stack;

public class Servidor {
    public static void main(String[] args) {
        int puerto = 5050; // usa un puerto libre
        try (ServerSocket serverSocket = new ServerSocket(puerto)) {
            System.out.println("Servidor iniciado en el puerto " + puerto);

            Socket socket = serverSocket.accept();
            System.out.println("Cliente conectado: " + socket.getInetAddress());

            BufferedReader entrada = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            PrintWriter salida = new PrintWriter(socket.getOutputStream(), true);

            String mensaje;
            while ((mensaje = entrada.readLine()) != null) {
                System.out.println("Cliente: " + mensaje);

                if (mensaje.equalsIgnoreCase("salir")) {
                    salida.println("Conexión finalizada.");
                    break;
                }

                try {
                    double resultado = evaluar(mensaje);
                    salida.println("Resultado: " + resultado);
                } catch (Exception e) {
                    salida.println("Servidor recibio: " + mensaje);
                }
            }

            socket.close();
            System.out.println("Servidor cerrado.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Evaluador básico de expresiones matemáticas (+, -, *, /)
    public static double evaluar(String expr) {
        return new Object() {
            int pos = -1, ch;

            void siguienteChar() {
                ch = (++pos < expr.length()) ? expr.charAt(pos) : -1;
            }

            boolean comer(int charEsperado) {
                while (ch == ' ') siguienteChar();
                if (ch == charEsperado) {
                    siguienteChar();
                    return true;
                }
                return false;
            }

            double parse() {
                siguienteChar();
                double x = parseExpresion();
                if (pos < expr.length()) throw new RuntimeException("Caracter inesperado: " + (char)ch);
                return x;
            }

            double parseExpresion() {
                double x = parseTermino();
                for (;;) {
                    if (comer('+')) x += parseTermino();
                    else if (comer('-')) x -= parseTermino();
                    else return x;
                }
            }

            double parseTermino() {
                double x = parseFactor();
                for (;;) {
                    if (comer('*')) x *= parseFactor();
                    else if (comer('/')) x /= parseFactor();
                    else return x;
                }
            }

            double parseFactor() {
                if (comer('+')) return parseFactor();
                if (comer('-')) return -parseFactor();

                double x;
                int inicio = this.pos;
                if (comer('(')) {
                    x = parseExpresion();
                    comer(')');
                } else if ((ch >= '0' && ch <= '9') || ch == '.') {
                    while ((ch >= '0' && ch <= '9') || ch == '.') siguienteChar();
                    x = Double.parseDouble(expr.substring(inicio, this.pos));
                } else {
                    throw new RuntimeException("Caracter inesperado: " + (char)ch);
                }
                return x;
            }
        }.parse();
    }
}
